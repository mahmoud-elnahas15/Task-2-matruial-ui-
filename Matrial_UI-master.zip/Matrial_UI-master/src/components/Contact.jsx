import {
  Container,
  TextField,
  Button,
  Box,
  Typography,
} from "@mui/material";

export default function Contact() {
  return (
    <Container sx={{ py: 6 }}>
      <Typography variant="h4" textAlign="center" mb={4}>
        Contact Us
      </Typography>

      <Box maxWidth={500} mx="auto">
        <TextField fullWidth label="Name" margin="normal" />
        <TextField fullWidth label="Email" margin="normal" />
        <TextField
          fullWidth
          label="Message"
          multiline
          rows={4}
          margin="normal"
        />
        <Button fullWidth variant="contained" sx={{ mt: 2 }}>
          Submit
        </Button>
      </Box>
    </Container>
  );
}
