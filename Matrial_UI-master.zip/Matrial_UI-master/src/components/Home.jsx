import { Box, Typography, Button } from "@mui/material";

export default function Home() {
  return (
    <Box
      sx={{
        minHeight: "90vh",
        display: "flex",
        flexDirection: "column",
        justifyContent: "center",
        alignItems: "center",
        textAlign: "center",
        bgcolor: "#f5f5f5",
      }}
    >
      <Typography variant="h3" gutterBottom>
        Welcome To Our Restaurant
      </Typography>

      <Button variant="contained" size="large">
        View Menu
      </Button>
    </Box>
  );
}
