import { Box, Typography } from "@mui/material";

export default function Footer() {
  return (
    <Box sx={{ bgcolor: "#222", color: "#fff", p: 3, textAlign: "center" }}>
      <Typography>Fresh Food</Typography>
      <Typography>Made With Love</Typography>
    </Box>
  );
}
